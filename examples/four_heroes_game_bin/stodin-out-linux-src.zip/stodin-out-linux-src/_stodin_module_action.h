#ifndef _STODIN_ACTION_INCLUDED
#define _STODIN_ACTION_INCLUDED
#include <cstdint>
#include <exception>
#include "__stodin_types.h"
#include "__stodin_string.h"
#include "__stodin_array.h"
#include "__stodin_dict.h"
#include "__stodin_io.h"
#include "__stodin_file.h"
#include "__stodin_common.h"
using namespace std;
#include "_stodin_module_hero.h"
#include "_stodin_lib_random.h"
using namespace _stodin_module_hero;
using namespace _stodin_lib_random;
namespace _stodin_module_action{
typedef _stodin_module_hero::Hero Hero;
typedef _stodin_module_hero::HeroType HeroType;
const int64_t PENALTY  {5};

extern void get_hero_name(__stodin_string &name, const Hero &hero);

extern void get_target_index(int64_t &index, const __stodin_array<Hero> &heroes, const __stodin_bool &good);

extern void attack(__stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes, const int64_t &selfIdx, const __stodin_bool &good);

extern void stun(__stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes, const int64_t &selfIdx, const __stodin_bool &good);

extern void heel(__stodin_array<Hero> &ourHeroes, const int64_t &selfIdx, const __stodin_bool &good);

extern void heel_all(__stodin_array<Hero> &ourHeroes, const int64_t &selfIdx);

extern void inspires_all(__stodin_array<Hero> &ourHeroes, const int64_t &selfIdx);

extern void attack_all_by(__stodin_array<Hero> &enemyHeroes, const Hero &ourHero);

extern void ressurect(__stodin_array<Hero> &ourHeroes, const int64_t &selfIdx);
}
#endif
