#include "_stodin_module_four_heroes_game.h"
namespace _stodin_module_four_heroes_game{
void print_actions(   // 10
    const Hero &hero){   // 11
    print(DIVIDING_LINE);print("Choose action:\n");   // 12
    int64_t counter  {1};   // 13
    for(auto &action: hero.actions){   // 14
        int64_t hai  {static_cast<int64_t>(action)};   // 15
        print(counter);print(". ");print(_stodin_module_hero::HERO_ACTION_STRING.at(hai));print('\n');   // 16
        counter += 1;    // 17
}}
void get_actions_number(   // 19
    int64_t &number   // 20
    , const Hero &hero, const __stodin_bool &good){   // 21
    int64_t sz;size(sz, hero.actions);   // 22
    if(sz == 1){   // 23
        number = 0;   // 24
        return;   // 25
    }
    if(good){   // 26
        print_actions(hero);   // 27
        scan(number);   // 28
        number -= 1;    // 29
        if(number >= sz){   // 30
            number = -1;   // 31
        }
        if(number < 0){   // 32
            number = -1;   // 33
    }}
    else{   // 34
        _stodin_lib_random::randint(number, 1, sz);number -= 1;    // 35
}}
void clean_zero_health_heroes(   // 38
    __stodin_array<Hero> &heroes   // 39
    ){
    int64_t sz;size(sz, heroes);sz -= 1;    // 40
    for(int64_t i = sz; i > -1; i += -1){   // 41
        if(heroes.at(i).health <= 0){   // 42
            erase(heroes, i);   // 43
}}}
void fight(   // 45
    __stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes   // 46
    , const int64_t &selfIdx, const __stodin_bool &good){   // 47
    int64_t nameIdx  {static_cast<int64_t>(ourHeroes.at(selfIdx).type)};   // 48
    __stodin_string heroName  {HERO_TYPE_STRING.at(nameIdx)};   // 49
    if(ourHeroes.at(selfIdx).type == HeroType::Troll){   // 50
        ourHeroes.at(selfIdx).health += 5;    // 51
    }
    if(ourHeroes.at(selfIdx).type == HeroType::Ghost){   // 52
        ourHeroes.at(selfIdx).health += 3;    // 53
    }
    if(ourHeroes.at(selfIdx).health > ourHeroes.at(selfIdx).maxHealth){   // 54
        ourHeroes.at(selfIdx).health = ourHeroes.at(selfIdx).maxHealth;   // 55
    }
    if(ourHeroes.at(selfIdx).stunned){   // 56
        ourHeroes.at(selfIdx).stunned = 0;   // 57
        print(heroName);print(" regains consciousness. Press Enter.");   // 58
        wait_enter();   // 59
        return;   // 60
    }
    int64_t actionNumber  {-1};   // 61
    get_actions_number(actionNumber, ourHeroes.at(selfIdx), good);   // 62
    if(actionNumber == -1){   // 63
        print("No such an action. ");print(heroName);print(" gets penalty.\n");   // 64
        ourHeroes.at(selfIdx).health -= PENALTY;    // 65
    }
    else{   // 66
        _stodin_module_hero::HeroAction action  {ourHeroes.at(selfIdx).actions.at(actionNumber)};   // 67
        if(action == _stodin_module_hero::HeroAction::Attack){   // 68
            _stodin_module_action::attack(ourHeroes, enemyHeroes, selfIdx, good);   // 69
        }
        else if(action == _stodin_module_hero::HeroAction::Stun){   // 70
            _stodin_module_action::stun(ourHeroes, enemyHeroes, selfIdx, good);   // 71
        }
        else if(action == _stodin_module_hero::HeroAction::Heal){   // 72
            _stodin_module_action::heel(ourHeroes, selfIdx, good);   // 73
        }
        else if(action == _stodin_module_hero::HeroAction::MassHeal){   // 74
            _stodin_module_action::heel_all(ourHeroes, selfIdx);   // 75
        }
        else if(action == _stodin_module_hero::HeroAction::Inspire){   // 76
            _stodin_module_action::inspires_all(ourHeroes, selfIdx);   // 77
        }
        else if(action == _stodin_module_hero::HeroAction::MassAttack){   // 78
            _stodin_module_action::attack_all_by(enemyHeroes, ourHeroes.at(selfIdx));   // 79
        }
        else if(action == _stodin_module_hero::HeroAction::Ressurect){   // 80
            _stodin_module_action::ressurect(ourHeroes, selfIdx);   // 81
        }
        if(action != HeroAction::Inspire){   // 82
            ourHeroes.at(selfIdx).inspired = 0;   // 83
    }}
    clean_zero_health_heroes(ourHeroes);   // 84
    clean_zero_health_heroes(enemyHeroes);   // 85
    if(good == 0){   // 86
        print("Press Enter.");   // 87
        wait_enter();   // 88
}}
void print_all_heroes(   // 91
    const __stodin_array<Hero> &goodHeroes, const __stodin_array<Hero> &badHeroes){   // 92
    int64_t idx  {0};   // 93
    int64_t gsz;size(gsz, goodHeroes);gsz -= 1;    // 94
    print('\n');print(DIVIDING_LINE);   // 95
    for(int64_t i = gsz; i > -1; i += -1){   // 96
        idx = i;idx += 1;    // 97
        _stodin_module_hero::print_hero(goodHeroes.at(i), idx);   // 98
    }
    print("\nvs\n\n");   // 99
    idx = 1;   // 100
    for(auto &h: badHeroes){   // 101
        _stodin_module_hero::print_hero(h, idx);   // 102
        idx += 1;    // 103
    }
    print(DIVIDING_LINE);   // 104
}
void check_battle(   // 106
    __stodin_bool &res   // 107
    , const __stodin_array<Hero> &goodHeroes, const __stodin_array<Hero> &badHeroes){   // 108
    res = 1;   // 109
    int64_t sum  {0};   // 110
    for(auto &h: goodHeroes){   // 111
        sum += h.health;    // 112
    }
    if(sum == 0){   // 113
        res = 0;   // 114
    }
    sum = 0;   // 115
    for(auto &h: badHeroes){   // 116
        sum += h.health;    // 117
    }
    if(sum == 0){   // 118
        res = 0;   // 119
}}
void make_bad_team(   // 121
    __stodin_array<Hero> &badHeroes   // 122
    , const int64_t &turn){   // 123
    if(turn == 0){   // 124
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 125
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 126
        badHeroes.create(); _stodin_module_hero::make_troll(badHeroes.at(-1));   // 127
        badHeroes.create(); _stodin_module_hero::make_witch(badHeroes.at(-1));   // 128
    }
    else if(turn == 1){   // 129
        badHeroes.create(); _stodin_module_hero::make_zombie(badHeroes.at(-1));   // 130
        badHeroes.create(); _stodin_module_hero::make_ghost(badHeroes.at(-1));   // 131
        badHeroes.create(); _stodin_module_hero::make_ghost(badHeroes.at(-1));   // 132
        badHeroes.create(); _stodin_module_hero::make_lich(badHeroes.at(-1));   // 133
    }
    else if(turn == 2){   // 134
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 135
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 136
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 137
        badHeroes.create(); _stodin_module_hero::make_hydra(badHeroes.at(-1));   // 138
    }
    else if(turn == 3){   // 139
        badHeroes.create(); _stodin_module_hero::make_lich(badHeroes.at(-1));   // 140
        badHeroes.create(); _stodin_module_hero::make_zombie(badHeroes.at(-1));   // 141
        badHeroes.create(); _stodin_module_hero::make_zombie(badHeroes.at(-1));   // 142
        badHeroes.create(); _stodin_module_hero::make_zombie(badHeroes.at(-1));   // 143
    }
    else if(turn == 4){   // 144
        badHeroes.create(); _stodin_module_hero::make_troll(badHeroes.at(-1));   // 145
        badHeroes.create(); _stodin_module_hero::make_goblin(badHeroes.at(-1));   // 146
        badHeroes.create(); _stodin_module_hero::make_witch(badHeroes.at(-1));   // 147
        badHeroes.create(); _stodin_module_hero::make_hydra(badHeroes.at(-1));   // 148
    }
    else if(turn == 5){   // 149
        badHeroes.create(); _stodin_module_hero::make_troll(badHeroes.at(-1));   // 150
        badHeroes.create(); _stodin_module_hero::make_witch(badHeroes.at(-1));   // 151
        badHeroes.create(); _stodin_module_hero::make_witch(badHeroes.at(-1));   // 152
        badHeroes.create(); _stodin_module_hero::make_witch(badHeroes.at(-1));   // 153
    }
    else if(turn == 6){   // 154
        badHeroes.create(); _stodin_module_hero::make_zombie(badHeroes.at(-1));   // 155
        badHeroes.create(); _stodin_module_hero::make_lich(badHeroes.at(-1));   // 156
        badHeroes.create(); _stodin_module_hero::make_vampire(badHeroes.at(-1));   // 157
        badHeroes.create(); _stodin_module_hero::make_vampire(badHeroes.at(-1));   // 158
}}
void do_match(   // 161
    __stodin_array<Hero> &goodHeroes   // 162
    , const int64_t &turn, const __stodin_bool &stunningFlag){   // 163
    __stodin_array<Hero> badHeroes;make_bad_team(badHeroes, turn);   // 164
    if(stunningFlag){   // 165
        for(int64_t i = 0; i < 2; i += 1){   // 166
            badHeroes.at(i).stunned = 1;   // 167
    }}
    int64_t goodPointer  {0};   // 168
    int64_t badPointer  {0};   // 169
    print_all_heroes(goodHeroes, badHeroes);   // 170
    __stodin_bool good  {1};   // 171
    for(__stodin_bool b;(check_battle(b, goodHeroes, badHeroes), b);){   // 172
        if(good){   // 173
            int64_t gsz;size(gsz, goodHeroes);   // 174
            if(goodPointer < gsz){   // 175
                print(">> ");   // 176
                int64_t idx  {goodPointer};idx += 1;    // 177
                print_hero(goodHeroes.at(goodPointer), idx);   // 178
                fight(goodHeroes, badHeroes, goodPointer, good);   // 179
                print_all_heroes(goodHeroes, badHeroes);   // 180
            }
            goodPointer += 1;    // 181
        }
        else{   // 182
            int64_t bsz;size(bsz, badHeroes);   // 183
            if(badPointer < bsz){   // 184
                fight(badHeroes, goodHeroes, badPointer, good);   // 185
                print_all_heroes(goodHeroes, badHeroes);   // 186
            }
            badPointer += 1;    // 187
        }
        good = !good;   // 188
        int64_t gsz;size(gsz, goodHeroes);   // 189
        int64_t bsz;size(bsz, badHeroes);   // 190
        if(goodPointer > gsz){   // 191
            if(badPointer > bsz){   // 192
                badPointer = 0;   // 193
                goodPointer = 0;   // 194
        }}
        if(badPointer > bsz){   // 195
            if(goodPointer > gsz){   // 196
                badPointer = 0;   // 197
                goodPointer = 0;   // 198
        }}
        if(bsz == 1){   // 199
            if(gsz > 2){   // 200
                print("The enemy is forced to retreat. \n\n");   // 201
                break;   // 202
}}}}
void choose_prize(   // 204
    int64_t &number   // 205
    ){
    print("Choose your prize:\n\n");   // 206
    print("1. A heeling spell (health +10 for all).\n");   // 207
    print("2. An inspiring prayer (inspire all).\n");   // 208
    print("3. A stunning roar (stun two nearest enemies).\n");   // 209
    scan(number);number -= 1;    // 210
    if(number > 2){   // 211
        number = -1;   // 212
}}
void use_prize(   // 214
    __stodin_array<Hero> &goodHeroes, __stodin_bool &stunningFlag   // 215
    , const int64_t &prizeNumber){   // 216
    stunningFlag = 0;   // 217
    if(prizeNumber == 0){   // 218
        for(auto &hero: goodHeroes){   // 219
            hero.health += 10;    // 220
    }}
    else if(prizeNumber == 1){   // 221
        for(auto &hero: goodHeroes){   // 222
            hero.inspired = 1;   // 223
    }}
    else if(prizeNumber == 2){   // 224
        stunningFlag = 1;   // 225
}}
   // 227
void _stodin_main(){   // 230
    __stodin_array<Hero> goodHeroes;   // 231
    goodHeroes.create(); _stodin_module_hero::make_guard(goodHeroes.at(-1));   // 232
    goodHeroes.create(); _stodin_module_hero::make_knight(goodHeroes.at(-1));   // 233
    goodHeroes.create(); _stodin_module_hero::make_mage(goodHeroes.at(-1));   // 234
    goodHeroes.create(); _stodin_module_hero::make_nun(goodHeroes.at(-1));   // 235
    __stodin_bool stunningFlag  {0};   // 236
    for(int64_t i = 0; i < MATCHES_AMOUNT; i += 1){   // 237
        do_match(goodHeroes, i, stunningFlag);   // 238
        int64_t sz;size(sz, goodHeroes);   // 239
        if(sz == 0){   // 240
            print("You lose the game. Game over. Press Enter.");   // 241
            wait_enter();   // 242
            return;   // 243
        }
        else if(sz < HEROES_AMOUNT){   // 244
            for(int64_t i = sz; i < HEROES_AMOUNT; i += 1){   // 245
                goodHeroes.create(); _stodin_module_hero::make_ghost(goodHeroes.at(-1));   // 246
        }}
        int64_t n  {MATCHES_AMOUNT};n -= i; n -= 1;    // 247
        if(n){   // 248
            print("You win the battle. ");print(n);print(" battles left.\n\n");   // 249
            int64_t prizeNumber;choose_prize(prizeNumber);   // 250
            use_prize(goodHeroes, stunningFlag, prizeNumber);   // 251
            print("Prepare to the next battle. Press Enter.");   // 252
            wait_enter();   // 253
    }}
    print("You win the game!!! Congratulations!!!\nPress Enter.");   // 254
    wait_enter();   // 255
}

}