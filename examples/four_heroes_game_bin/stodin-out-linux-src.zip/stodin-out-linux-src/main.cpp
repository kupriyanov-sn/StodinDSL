#include <iostream>
#include <exception>
#include "__stodin_common.h"
#include "_stodin_module_four_heroes_game.h"
using namespace _stodin_module_four_heroes_game;
int main(int argc, char** argv){
    try
    {
        _stodin_parse_args(argc, argv);
        _stodin_main();
    }
    catch(std::exception& e)
    {
        if(__stodinTrace.size())
        {
            for(auto s: __stodinTrace)
                std::cout << s << std::endl;
        }
        else
            std::cout << e.what() << std::endl;
    }
}
