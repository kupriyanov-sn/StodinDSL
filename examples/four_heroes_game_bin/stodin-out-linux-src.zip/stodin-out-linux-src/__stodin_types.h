#ifndef __STODIN_TYPES_H_INCLUDED
#define __STODIN_TYPES_H_INCLUDED

#include <cstdint>

typedef uint32_t __stodin_bool;

#endif // __STODIN_TYPES_H_INCLUDED
