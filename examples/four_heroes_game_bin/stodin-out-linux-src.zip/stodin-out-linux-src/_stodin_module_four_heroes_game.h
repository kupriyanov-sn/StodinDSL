#ifndef _STODIN_FOUR_HEROES_GAME_INCLUDED
#define _STODIN_FOUR_HEROES_GAME_INCLUDED
#include <cstdint>
#include <exception>
#include "__stodin_types.h"
#include "__stodin_string.h"
#include "__stodin_array.h"
#include "__stodin_dict.h"
#include "__stodin_io.h"
#include "__stodin_file.h"
#include "__stodin_common.h"
using namespace std;
#include "_stodin_module_hero.h"
#include "_stodin_module_action.h"
#include "_stodin_lib_random.h"
using namespace _stodin_module_hero;
using namespace _stodin_module_action;
using namespace _stodin_lib_random;
namespace _stodin_module_four_heroes_game{
typedef _stodin_module_hero::Hero Hero;
typedef _stodin_module_hero::HeroType HeroType;
const __stodin_string DIVIDING_LINE  {"===========================\n"};
const int64_t MATCHES_AMOUNT  {7};
const int64_t HEROES_AMOUNT  {4};

extern void print_actions(const Hero &hero);

extern void get_actions_number(int64_t &number, const Hero &hero, const __stodin_bool &good);

extern void clean_zero_health_heroes(__stodin_array<Hero> &heroes);

extern void fight(__stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes, const int64_t &selfIdx, const __stodin_bool &good);

extern void print_all_heroes(const __stodin_array<Hero> &goodHeroes, const __stodin_array<Hero> &badHeroes);

extern void check_battle(__stodin_bool &res, const __stodin_array<Hero> &goodHeroes, const __stodin_array<Hero> &badHeroes);

extern void make_bad_team(__stodin_array<Hero> &badHeroes, const int64_t &turn);

extern void do_match(__stodin_array<Hero> &goodHeroes, const int64_t &turn, const __stodin_bool &stunningFlag);

extern void choose_prize(int64_t &number);

extern void use_prize(__stodin_array<Hero> &goodHeroes, __stodin_bool &stunningFlag, const int64_t &prizeNumber);

extern void _stodin_main();
}
#endif
