#ifndef _STODIN_HERO_INCLUDED
#define _STODIN_HERO_INCLUDED
#include <cstdint>
#include <exception>
#include "__stodin_types.h"
#include "__stodin_string.h"
#include "__stodin_array.h"
#include "__stodin_dict.h"
#include "__stodin_io.h"
#include "__stodin_file.h"
#include "__stodin_common.h"
using namespace std;
#include "_stodin_lib_random.h"
using namespace _stodin_lib_random;
namespace _stodin_module_hero{
enum class HeroType: uint8_t{None, Knight, Nun, Guard, Mage, Goblin, Witch, Troll, Hydra, Zombie, Ghost, Lich, Vampire};
enum class HeroAction: uint8_t{Attack, Heal, Stun, Inspire, MassAttack, MassHeal, Ressurect};
struct Hero{public:
    HeroType type;
    int64_t health  {50};
    int64_t maxHealth  {50};
    int64_t maxStrength  {12};
    int64_t minStrength  {6};
    int64_t defence  {30};
    __stodin_bool inspired  {0};
    __stodin_bool stunned  {0};
    __stodin_array<HeroAction> actions;
};
const __stodin_array<__stodin_string> HERO_TYPE_STRING  {"None", "Knight", "Nun", "Guard", "Mage", "Goblin", "Witch", "Troll", "Hydra", "Zombie", "Ghost", "Lich", "Vampire"};
const __stodin_array<__stodin_string> HERO_ACTION_STRING  {"Attack", "Heal", "Stun", "Inspire", "Mass attack", "Mass heal", "Ressurect"};

extern void print_hero(const Hero &hero, const int64_t &idx);

extern void make_knight(Hero &hero);

extern void make_guard(Hero &hero);

extern void make_nun(Hero &hero);

extern void make_mage(Hero &hero);

extern void make_goblin(Hero &hero);

extern void make_witch(Hero &hero);

extern void make_hydra(Hero &hero);

extern void make_troll(Hero &hero);

extern void make_zombie(Hero &hero);

extern void make_ghost(Hero &hero);

extern void make_vampire(Hero &hero);

extern void make_lich(Hero &hero);
}
#endif
