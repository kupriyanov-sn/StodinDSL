#include "_stodin_module_hero.h"
namespace _stodin_module_hero{

   // 18
void print_hero(   // 21
    const Hero &hero, const int64_t &idx){   // 22
    int64_t hti  {static_cast<int64_t>(hero.type)};   // 23
    print(idx);print(". ");print(HERO_TYPE_STRING.at(hti));print("   hp: ");print(hero.health);print(" (");print(hero.maxHealth);print(')');   // 24
    if(hero.stunned){   // 25
        print(", stunned");   // 26
    }
    if(hero.inspired){   // 27
        print(", inspired");   // 28
    }
    print(".\n");   // 29
}
void make_knight(   // 31
    Hero &hero   // 32
    ){
    hero.type = HeroType::Knight;   // 33
    hero.health = 50;   // 34
    hero.maxHealth = 50;   // 35
    hero.maxStrength = 15;   // 36
    hero.minStrength = 8;   // 37
    hero.defence = 30;   // 38
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Inspire);   // 39
}
void make_guard(   // 41
    Hero &hero   // 42
    ){
    hero.type = HeroType::Guard;   // 43
    hero.health = 60;   // 44
    hero.maxHealth = 60;   // 45
    hero.maxStrength = 9;   // 46
    hero.minStrength = 6;   // 47
    hero.defence = 50;   // 48
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Stun);   // 49
}
void make_nun(   // 51
    Hero &hero   // 52
    ){
    hero.type = HeroType::Nun;   // 53
    hero.health = 40;   // 54
    hero.maxHealth = 40;   // 55
    hero.maxStrength = 6;   // 56
    hero.minStrength = 3;   // 57
    hero.defence = 10;   // 58
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Heal);add(hero.actions, HeroAction::MassHeal);add(hero.actions, HeroAction::Inspire);   // 59
}
void make_mage(   // 61
    Hero &hero   // 62
    ){
    hero.type = HeroType::Mage;   // 63
    hero.health = 40;   // 64
    hero.maxHealth = 40;   // 65
    hero.maxStrength = 7;   // 66
    hero.minStrength = 4;   // 67
    hero.defence = 15;   // 68
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Heal);add(hero.actions, HeroAction::Stun);add(hero.actions, HeroAction::MassAttack);   // 69
}
void make_goblin(   // 71
    Hero &hero   // 72
    ){
    hero.type = HeroType::Goblin;   // 73
    hero.health = 20;   // 74
    hero.maxHealth = 20;   // 75
    hero.maxStrength = 8;   // 76
    hero.minStrength = 5;   // 77
    hero.defence = 20;   // 78
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Stun);   // 79
}
void make_witch(   // 81
    Hero &hero   // 82
    ){
    hero.type = HeroType::Witch;   // 83
    hero.health = 40;   // 84
    hero.maxHealth = 40;   // 85
    hero.maxStrength = 7;   // 86
    hero.minStrength = 5;   // 87
    hero.defence = 15;   // 88
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Heal);add(hero.actions, HeroAction::Inspire);   // 89
}
void make_hydra(   // 91
    Hero &hero   // 92
    ){
    hero.type = HeroType::Hydra;   // 93
    hero.health = 70;   // 94
    hero.maxHealth = 70;   // 95
    hero.maxStrength = 12;   // 96
    hero.minStrength = 12;   // 97
    hero.defence = 30;   // 98
    add(hero.actions, HeroAction::MassAttack);   // 99
}
void make_troll(   // 101
    Hero &hero   // 102
    ){
    hero.type = HeroType::Troll;   // 103
    hero.health = 80;   // 104
    hero.maxHealth = 150;   // 105
    hero.maxStrength = 15;   // 106
    hero.minStrength = 7;   // 107
    hero.defence = 30;   // 108
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Stun);add(hero.actions, HeroAction::Inspire);   // 109
}
void make_zombie(   // 111
    Hero &hero   // 112
    ){
    hero.type = HeroType::Zombie;   // 113
    hero.health = 40;   // 114
    hero.maxHealth = 40;   // 115
    hero.maxStrength = 8;   // 116
    hero.minStrength = 8;   // 117
    hero.defence = 30;   // 118
    add(hero.actions, HeroAction::Attack);   // 119
}
void make_ghost(   // 121
    Hero &hero   // 122
    ){
    hero.type = HeroType::Ghost;   // 123
    hero.health = 15;   // 124
    hero.maxHealth = 15;   // 125
    hero.maxStrength = 5;   // 126
    hero.minStrength = 5;   // 127
    hero.defence = 40;   // 128
    add(hero.actions, HeroAction::Attack);add(hero.actions, HeroAction::Stun);   // 129
}
void make_vampire(   // 131
    Hero &hero   // 132
    ){
    hero.type = HeroType::Vampire;   // 133
    hero.health = 60;   // 134
    hero.maxHealth = 120;   // 135
    hero.maxStrength = 12;   // 136
    hero.minStrength = 10;   // 137
    hero.defence = 40;   // 138
    add(hero.actions, HeroAction::Attack);   // 139
}
void make_lich(   // 141
    Hero &hero   // 142
    ){
    hero.type = HeroType::Lich;   // 143
    hero.health = 60;   // 144
    hero.maxHealth = 60;   // 145
    hero.maxStrength = 12;   // 146
    hero.minStrength = 12;   // 147
    hero.defence = 50;   // 148
    add(hero.actions, HeroAction::MassAttack);add(hero.actions, HeroAction::Ressurect);   // 149
}

}