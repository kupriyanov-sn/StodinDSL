#include "_stodin_module_action.h"
namespace _stodin_module_action{
void get_hero_name(   // 9
    __stodin_string &name   // 10
    , const Hero &hero){   // 11
    int64_t nameIdx  {static_cast<int64_t>(hero.type)};   // 12
    name = _stodin_module_hero::HERO_TYPE_STRING.at(nameIdx);   // 13
}
void get_target_index(   // 15
    int64_t &index   // 16
    , const __stodin_array<Hero> &heroes, const __stodin_bool &good){   // 17
    if(good){   // 18
        print("Select hero index: ");   // 19
        scan(index);   // 20
        index -= 1;    // 21
    }
    else{   // 22
        int64_t lastHeroInx;size(lastHeroInx, heroes);lastHeroInx -= 1;    // 23
        _stodin_lib_random::randint(index, 0, lastHeroInx);   // 24
        __stodin_string heroName;get_hero_name(heroName, heroes.at(index));   // 25
        print("Selected hero: ");print(heroName);print(". ");   // 26
}}
static void _destroy_by(   // 28
    Hero &enemyHero   // 29
    , const Hero &hero){   // 30
    int64_t negDefence  {100};negDefence -= enemyHero.defence;    // 31
    int64_t r1;_stodin_lib_random::randint(r1, hero.minStrength, hero.maxStrength);   // 32
    if(hero.inspired){   // 33
        r1 = hero.maxStrength;   // 34
    }
    r1 *= negDefence; r1 /= 100;    // 35
    enemyHero.health -= r1;    // 36
}
void attack(   // 38
    __stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes   // 39
    , const int64_t &selfIdx, const __stodin_bool &good){   // 40
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 41
    int64_t ourSz;size(ourSz, ourHeroes);   // 42
    int64_t enemySz;size(enemySz, enemyHeroes);   // 43
    print(heroName);print(" attacks.\n");   // 44
    int64_t targetIdx;get_target_index(targetIdx, enemyHeroes, good);   // 45
    if(targetIdx < 0){   // 46
        targetIdx = enemySz;targetIdx += 1;    // 47
    }
    if(targetIdx < enemySz){   // 48
        _destroy_by(enemyHeroes.at(targetIdx), ourHeroes.at(selfIdx));   // 49
        if(ourHeroes.at(selfIdx).type == HeroType::Vampire){   // 50
            ourHeroes.at(selfIdx).health += 8;    // 51
            if(ourHeroes.at(selfIdx).health > ourHeroes.at(selfIdx).maxHealth){   // 52
                ourHeroes.at(selfIdx).health = ourHeroes.at(selfIdx).maxHealth;   // 53
    }}}
    else{   // 54
        print("No hero in selected position. ");print(heroName);print(" gets penalty.\n");   // 55
        ourHeroes.at(selfIdx).health -= PENALTY;    // 56
}}
void stun(   // 58
    __stodin_array<Hero> &ourHeroes, __stodin_array<Hero> &enemyHeroes   // 59
    , const int64_t &selfIdx, const __stodin_bool &good){   // 60
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 61
    int64_t enemySz;size(enemySz, enemyHeroes);   // 62
    print(heroName);print(" stuns.\n");   // 63
    int64_t targetIdx;get_target_index(targetIdx, enemyHeroes, good);   // 64
    if(targetIdx < 0){   // 65
        targetIdx = enemySz;targetIdx += 1;    // 66
    }
    if(targetIdx < enemySz){   // 67
        enemyHeroes.at(targetIdx).health -= ourHeroes.at(selfIdx).minStrength;    // 68
        int64_t stunChance;_stodin_lib_random::randint(stunChance, 0, 100);   // 69
        if(ourHeroes.at(selfIdx).inspired){   // 70
            enemyHeroes.at(targetIdx).health -= 1;    // 71
            stunChance += 10;    // 72
        }
        if(stunChance > enemyHeroes.at(targetIdx).defence){   // 73
            enemyHeroes.at(targetIdx).stunned = 1;   // 74
        }
        else{   // 75
            __stodin_string adversaryName;get_hero_name(adversaryName, enemyHeroes.at(targetIdx));   // 76
            print(adversaryName);print(" dodges a blow.\n");   // 77
    }}
    else{   // 78
        print("No hero in selected position. ");print(heroName);print(" gets penalty.\n");   // 79
        ourHeroes.at(selfIdx).health -= PENALTY;    // 80
}}
void heel(   // 83
    __stodin_array<Hero> &ourHeroes   // 84
    , const int64_t &selfIdx, const __stodin_bool &good){   // 85
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 86
    int64_t ourSz;size(ourSz, ourHeroes);   // 87
    print(heroName);print(" heels.\n");   // 88
    int64_t targetIdx;get_target_index(targetIdx, ourHeroes, good);   // 89
    if(targetIdx < 0){   // 90
        targetIdx = ourSz;targetIdx += 1;    // 91
    }
    if(targetIdx < ourSz){   // 92
        int64_t r1;_stodin_lib_random::randint(r1, 3, 10);   // 93
        if(ourHeroes.at(selfIdx).inspired){   // 94
            r1 += 5;    // 95
        }
        ourHeroes.at(targetIdx).health += r1;    // 96
        if(ourHeroes.at(targetIdx).health > ourHeroes.at(targetIdx).maxHealth){   // 97
            ourHeroes.at(targetIdx).health = ourHeroes.at(targetIdx).maxHealth;   // 98
    }}
    else{   // 99
        print("No hero in selected position. ");print(heroName);print(" gets penalty.\n");   // 100
        ourHeroes.at(selfIdx).health -= PENALTY;    // 101
}}
void heel_all(   // 103
    __stodin_array<Hero> &ourHeroes   // 104
    , const int64_t &selfIdx){   // 105
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 106
    print(heroName);print(" heels all.\n");   // 107
    for(auto &hero: ourHeroes){   // 108
        int64_t r1;_stodin_lib_random::randint(r1, 2, 4);   // 109
        if(ourHeroes.at(selfIdx).inspired){   // 110
            r1 += 1;    // 111
        }
        hero.health += r1;    // 112
        if(hero.health > hero.maxHealth){   // 113
            hero.health = hero.maxHealth;   // 114
}}}
void inspires_all(   // 116
    __stodin_array<Hero> &ourHeroes   // 117
    , const int64_t &selfIdx){   // 118
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 119
    print(heroName);print(" inspires all.\n");   // 120
    for(auto &hero: ourHeroes){   // 121
        hero.inspired = 1;   // 122
}}
void attack_all_by(   // 125
    __stodin_array<Hero> &enemyHeroes   // 126
    , const Hero &ourHero){   // 127
    __stodin_string heroName;get_hero_name(heroName, ourHero);   // 128
    print(heroName);print(" attack all.\n");   // 129
    for(auto &hero: enemyHeroes){   // 130
        int64_t r1;_stodin_lib_random::randint(r1, 3, ourHero.minStrength);   // 131
        if(ourHero.inspired){   // 132
            r1 += 1;    // 133
        }
        hero.health -= r1;    // 134
}}
void ressurect(   // 136
    __stodin_array<Hero> &ourHeroes   // 137
    , const int64_t &selfIdx){   // 138
    __stodin_string heroName;get_hero_name(heroName, ourHeroes.at(selfIdx));   // 139
    int64_t ourSz;size(ourSz, ourHeroes);   // 140
    if(ourSz < 4){   // 141
        print(heroName);print(" ressurects a zombie.\n");   // 142
        ourHeroes.create(); _stodin_module_hero::make_zombie(ourHeroes.at(-1));   // 143
    }
    else{   // 144
        for(auto &hero: ourHeroes){   // 145
            if(hero.health < hero.maxHealth){   // 146
                hero.health = hero.maxHealth;   // 147
                int64_t anotherNameIdx  {static_cast<int64_t>(hero.type)};   // 148
                __stodin_string anotherHeroName  {HERO_TYPE_STRING.at(anotherNameIdx)};   // 149
                print(heroName);print(" restore ");print(anotherHeroName);print(".\n");   // 150
                break;   // 151
}}}}

}